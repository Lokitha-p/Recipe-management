package recipe;

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

interface RecipeActions {
    void addRecipe(Recipe recipe);
    void displayRecipes();
}

interface MealPlanActions {
    void createMealPlan(MealPlan mealPlan);
    void displayMealPlans();
}

class Recipe {
    private String name;
    private String category;
    private String instructions;

    public Recipe(String name, String category, String instructions) {
        this.name = name;
        this.category = category;
        this.instructions = instructions;
    }

    public String getName() { return name; }
    public String getCategory() { return category; }
    public String getInstructions() { return instructions; }
}


class MealPlan {
    private String name;
    private ArrayList<Recipe> recipes;

    public MealPlan(String name) {
        this.name = name;
        this.recipes = new ArrayList<>();
    }

    public void addRecipe(Recipe recipe) {
        recipes.add(recipe);
    }

    public String getName() { return name; }
    public ArrayList<Recipe> getRecipes() { return recipes; }
}

class RecipeManager implements RecipeActions {
    private ArrayList<Recipe> recipes = new ArrayList<>();

    @Override
    public void addRecipe(Recipe recipe) {
        recipes.add(recipe);
        RecipeDatabase.insertRecipe(recipe);
    }

    @Override
    public void displayRecipes() {
        ArrayList<Recipe> recipesFromDB = RecipeDatabase.getRecipes();
        for (Recipe recipe : recipesFromDB) {
            System.out.println("Recipe: " + recipe.getName() + " | Category: " + recipe.getCategory());
        }
    }
}

class MealPlanManager implements MealPlanActions {
    private ArrayList<MealPlan> mealPlans = new ArrayList<>();

    @Override
    public void createMealPlan(MealPlan mealPlan) {
        mealPlans.add(mealPlan);
        MealPlanDatabase.insertMealPlan(mealPlan);
    }

    @Override
    public void displayMealPlans() {
        ArrayList<MealPlan> mealPlansFromDB = MealPlanDatabase.getMealPlans();
        for (MealPlan plan : mealPlansFromDB) {
            System.out.println("Meal Plan: " + plan.getName());
            for (Recipe recipe : plan.getRecipes()) {
                System.out.println(" - Recipe: " + recipe.getName());
            }
        }
    }
}

class DatabaseConnection {
    public static Connection getConnection() {
        String url = "jdbc:mysql://localhost:3306/recipe_managements";
        String user = "root";
        String password = "nandy131205@#";

        try {
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}

class RecipeDatabase {
    public static void insertRecipe(Recipe recipe) {
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            String query = "INSERT INTO Recipes (name, category, instructions) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, recipe.getName());
                stmt.setString(2, recipe.getCategory());
                stmt.setString(3, recipe.getInstructions());
                stmt.executeUpdate();
                System.out.println("Recipe added to database!");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static ArrayList<Recipe> getRecipes() {
        ArrayList<Recipe> recipes = new ArrayList<>();
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            String query = "SELECT * FROM Recipes";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {
                while (rs.next()) {
                    String name = rs.getString("name");
                    String category = rs.getString("category");
                    String instructions = rs.getString("instructions");
                    recipes.add(new Recipe(name, category, instructions));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return recipes;
    }
}

class MealPlanDatabase {
    public static void insertMealPlan(MealPlan mealPlan) {
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            String query = "INSERT INTO MealPlans (name, start_date, end_date) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, mealPlan.getName());
                stmt.setDate(2, Date.valueOf("2024-11-15")); // Example start date
                stmt.setDate(3, Date.valueOf("2024-11-21")); // Example end date
                stmt.executeUpdate();
                System.out.println("Meal Plan added to database!");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static ArrayList<MealPlan> getMealPlans() {
        ArrayList<MealPlan> mealPlans = new ArrayList<>();
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            String query = "SELECT * FROM MealPlans";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {
                while (rs.next()) {
                    String name = rs.getString("name");
                    mealPlans.add(new MealPlan(name));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return mealPlans;
    }
}

public class OnlineRecipe {
    public static void main(String[] args) {
        RecipeManager recipeManager = new RecipeManager();
        MealPlanManager mealPlanManager = new MealPlanManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Add Recipe");
            System.out.println("2. Create Meal Plan");
            System.out.println("3. View Recipes");
            System.out.println("4. View Meal Plans");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter recipe name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter category: ");
                    String category = scanner.nextLine();
                    System.out.print("Enter instructions: ");
                    String instructions = scanner.nextLine();

                    Recipe recipe = new Recipe(name, category, instructions);
                    recipeManager.addRecipe(recipe);
                    break;

                case 2:
                    System.out.print("Enter meal plan name: ");
                    String planName = scanner.nextLine();
                    MealPlan mealPlan = new MealPlan(planName);

                    System.out.print("Enter number of recipes to add: ");
                    int numRecipes = scanner.nextInt();
                    scanner.nextLine();

                    for (int i = 0; i < numRecipes; i++) {
                        System.out.print("Enter recipe name for meal plan: ");
                        String recipeName = scanner.nextLine();
                        mealPlan.addRecipe(new Recipe(recipeName, "General", "Sample instructions"));
                    }

                    mealPlanManager.createMealPlan(mealPlan);
                    break;

                case 3:
                    recipeManager.displayRecipes();
                    break;

                case 4:
                    mealPlanManager.displayMealPlans();
                    break;

                case 5:
                    System.out.println("Exiting program.");
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
