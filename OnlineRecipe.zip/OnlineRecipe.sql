-- Step 1: Create the Database
CREATE DATABASE recipe_managements;

-- Step 2: Use the Database
USE recipe_managements;

-- Step 3: Create the Recipes Table
CREATE TABLE Recipes (
    recipe_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    instructions TEXT,
    servings INT,
    prep_time INT,
    cook_time INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Step 4: Create the Ingredients Table
CREATE TABLE Ingredients (
    ingredient_id INT AUTO_INCREMENT PRIMARY KEY,
    recipe_id INT,
    name VARCHAR(100) NOT NULL,
    quantity DECIMAL(5,2),
    unit VARCHAR(20),
    FOREIGN KEY (recipe_id) REFERENCES Recipes(recipe_id) ON DELETE CASCADE
);

-- Step 5: Create the MealPlans Table
CREATE TABLE MealPlans (
    meal_plan_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    start_date DATE,
    end_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Step 6: Create the MealPlanRecipes Table
CREATE TABLE MealPlanRecipes (
    meal_plan_id INT,
    recipe_id INT,
    day_of_week VARCHAR(15),
    meal_type VARCHAR(20),
    PRIMARY KEY (meal_plan_id, recipe_id, day_of_week, meal_type),
    FOREIGN KEY (meal_plan_id) REFERENCES MealPlans(meal_plan_id) ON DELETE CASCADE,
    FOREIGN KEY (recipe_id) REFERENCES Recipes(recipe_id) ON DELETE CASCADE
);
